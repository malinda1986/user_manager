const api = require('./api');

module.exports = {
    baseURI: '/',
    api
};
