const Users = require('./user');
module.exports = Users;
