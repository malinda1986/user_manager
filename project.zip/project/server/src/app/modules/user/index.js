const controller = require('./controller');
const routes = require('./route');
module.exports = {
    controller,
    routes
};
